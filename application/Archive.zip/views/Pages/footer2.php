<!-- ========= JS Files =========  -->
<!-- Bootstrap -->
<script src="<?php echo base_url() ?>assets/js/lib/bootstrap.bundle.min.js"></script>
<!-- Ionicons -->
<script type="module" src="https://cdn.jsdelivr.net/npm/ionicons@latest/dist/ionicons/ionicons.esm.js"></script>
<!-- Splide -->
<script src="<?php echo base_url() ?>assets/js/plugins/splide/splide.min.js"></script>
<!-- Base Js File -->
<script src="<?php echo base_url() ?>assets/js/base.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script type="text/javascript">
	$(document).ready(function() {
		$('.js-example-basic-single').select2();
	});
</script>
</body>

</html>