<?php

class payment_model extends CI_Model {

    public function get_bank_info()
    {
        $this->db->select('*');
        $this->db->from('ms_payment');
        $this->db->where('payment_active', 'Y');
        $this->db->where('payment_name Not like "CASH"');
        $query = $this->db->get();
        return $query;
    }

    public function transaction_detail($id)
    {
        $this->db->select('*');
        $this->db->from('transaction_register');
        $this->db->join('ms_class', 'transaction_register.transaction_class_id = ms_class.class_id');
        $this->db->where('transaction_register_id', $id);
        $query = $this->db->get();
        return $query;
    }
    public function updatepaymenttype($data, $transaction_id)
    {
        $this->db->where('transaction_register_id', $transaction_id);
        $update = $this->db->update('transaction_register', $data);
        return $update;
    }
    public function check_transaction_page($id)
    {
        $this->db->select('*');
        $this->db->from('transaction_register');
        $this->db->where('transaction_register_id', $id);
        $query = $this->db->get();
        return $query;
    }
}

?>